
/*
	Basic Setup
*/
  var api_key = "mzymebCsyY3IKN5JIeVZqHADIaq8rZoq5bEx7AbHw";
  var pond_token = "dSPnaN";
		var max_displayed_results = 12;




		/*
			Advanced Setup, be careful editing anything below this line!
		*/
  $(function() {
    // Setup fishpond object
    var fishpond = new Fishpond(api_key);

    // Bind fishpond events
    fishpond.ready(fishpondReady);
    fishpond.error(fishpondError);
    fishpond.loading(fishpondLoading);
    fishpond.resultsUpdated(fishpondResultsUpdated);

			// Storage for previous tags, to test if query needs to be processed
			var lastTags = {};
			var lastFilters = {};


    // Initialise fishpond
    fishpond.init(pond_token);



    // Fishpond::ready
    function fishpondReady(pond){


				$("#search ul").hide();

				$("#loading").fadeOut(800, function(){
				$("#query-and-results").fadeIn(800, function(){
				//$("#results").html('<ul class="thumbnails"><li></li></ul>');

	          // Setup isotope
	          var list = $("#results ul")
	          list.isotope({
	            itemSelector: 'li',
	            filter: 'li[data-visible="1"]',
	            sortBy: 'score',
	            layoutMode: 'masonry',
							masonry: {
						    columnWidth: 80
						  },
	            getSortData: {
	              score: function ( $elem ) {
	                return parseInt($elem.attr('data-score'), 10);
	              }
	            }
	          });

	          // Enable jQuery-UI Sliders
	          $(".slider").slider({
	            value: 10,
	            min: -2,
	            max: 22,
				step: 0.01,
	            slide: processQuery
	            //stop: processQuery
	          });

	          // Add event handlers to filter checkboxes
	          $("input[type='checkbox']").change(processQuery);

	          // Add search check interval timer
	          setInterval(processSearch, 100);

						// Intialise default query
	          processQuery();
						updateFavourites();

						/*
						setInterval(function(){
							processQuery();
						}, 50);
						*/
					});
				});

			$('#search ul li').live('click', function(){
				processQuery();
				updateFavourites();
			});


			 // Call from Nicholas 2013-08-22
    		$('body *[data-bind="fish-count"]').html(pond.fish_count); //fixed fish count
    }



    // Fishpond::error
    function fishpondError(message){
      alert(message);
    }

    // Fishpond::loading
    function fishpondLoading(percentage){
      $("#loading h1").html("Loading... " + parseInt((percentage * 100), 10) + "%");
    }

    // Fishpond::resultsUpdated
    function fishpondResultsUpdated(results){


      var list = $("#results ul");
      list.find("li").attr('data-visible', 0);

      for(var resultIndex in results){
        var result = results[resultIndex];
        var newItem = false;
        var item = list.find("li[data-id='" + result.fish.id + "']").first();

        if(item.length == 0){
          newItem = true;
          item = createNewItem(result);
        }

        if(newItem){
          list.isotope('insert', item);
        }

					decorateItem(item, resultIndex, result);
      }

      list.isotope('updateSortData', list.find("li")).isotope({sortBy: 'score', sortAscending: true});
    }

    // createNewItem
    // Convenience method to generate new list item from a result
    function createNewItem(result){
      var item = $("#template-fish").clone();
				item.attr("id", "");
      item.attr('data-id', result.fish.id);
      item.attr('title', result.fish.title);
      item.attr('data-content', "Metadata not loaded.");

      var thumbnail = item.find(".thumbnail");

      item.click(function(){
					showFishMetadata($(this).attr("data-id"));
      });

      return item;
    }

			// refreshMetadata
			// Loads metadata for a result item on the page, adds the image to the background
			function refreshMetadata(fish_id){
				fishpond.get_fish(fish_id, function(fish){
        var item = $("#results ul li[data-id='" + fish.id + "']");
					var thumbnail = item.find(".thumbnail");
        thumbnail.css({'background': "url('" + fish.metadata.thumbnail_url + "') no-repeat", 'background-size': '100%'});
        console.log(fish.metadata);
					decorateModal(fish);
      });
			}

			// decorateModal
			// Decorates the internals of a modal window, just fish metadata
			function decorateModal(fish){
				var modal = $('.modal[data-id="' + fish.id + '"]');
				if(modal.length > 0){
					modal.find('*[data-bind="description"]').html(fish.metadata.description);
					modal.find('*[data-bind="image"]').attr('src', fish.metadata.image_url);
					modal.find('*[data-bind="external_url"]').attr('href', fish.metadata.url);
					modal.find('*[data-bind="portal_url"]').attr('href', fish.metadata.portal_url);
					}
			}

			// showFishMetadata
			// Opens a modal window and loads the metadata from the API
			function showFishMetadata(fish_id){
      var modal = $('#template-modal').clone();
				var fish = fishpond.pond.find_fish(fish_id);

				modal.attr('id', '');
				modal.attr('data-id', fish_id);
      modal.find('*[data-bind="title"]').html(fish.title);

				var favouritesButton = modal.find('*[data-bind="favourites"]');
				if(isFavourite(fish_id)){
					favouritesButton.html("Remove from favourites");
					favouritesButton.click(function(){
						removeFromFavourites(fish_id);
					});
				} else {
					favouritesButton.html("Add to favourites");
					favouritesButton.click(function(){
						addToFavourites(fish_id);
					});
				}

				modal.on('hidden', function(){ $(this).detach(); });
				modal.on('shown', function(){
					refreshMetadata(fish_id);
				});
      modal.modal('show');
			}

    // decorateItem
    // Convenience method to populate fish content
    function decorateItem(item, position, result){
      var thumbnail = item.find(".thumbnail");
      item.attr('data-position', position);
      item.attr('data-score', result.score);

				item.css({"z-index": 1000 - position});

				item.find("*[data-bind='title']").html(result.fish.title);
				item.find("*[data-bind='position']").html(position + 1);
				item.find("*[data-bind='score']").html(result.score);

				if(position < max_displayed_results){
					item.attr('data-visible', 1);
					refreshMetadata(result.fish.id);
				}
    }

    // processQuery
    // Convenience method for compiling current form settings into a query
    function processQuery(){
      var tags = {};
      var filters = {};
				var shouldProcessQuery = false;

      // Collect slider values
      $(".slider").each(function(){
        var slider = $(this);
        if(slider.prev(":checked").length > 0){
						slider.parents('.control-group').removeClass('disabled');
						var value = Math.round(parseFloat(slider.slider('value')));
						if(value < 0) value = 0;
						if(value > 20) value = 20;
          tags[slider.attr('data-slug')] = value;
        } else {
						slider.parents('.control-group').addClass('disabled');
          tags[slider.attr('data-slug')] = false;
        }
      });

      // Collect filter values
      $(".filter:checked").each(function(){
        var filter = $(this);
        filters[filter.attr('data-slug')] = 1;
      });

// Removed lines below were stopping uncheck boxes working until slide again (Jon: 29/08/2013)
// 				for(var tagKey in tags){
// 					if(tags[tagKey] != lastTags[tagKey]) shouldProcessQuery = true
// 				}
//
// 				if(shouldProcessQuery == false){
// 					for(var filterKey in filters){
// 						if(filters[filterKey] != lastFilters[filterKey]) shouldProcessQuery = true
// 					}
// 				}
//
// 				if(shouldProcessQuery){
// 					console.log(tags);
          fishpond.query(tags, filters);
				}

				// lastTags = tags;
// 				lastFilters = filters;
//     }

    // processSearch
    // Convenience method for processing text-based searches
    function processSearch(){
      var input = $("#search input");
      var searchString = input.val();

      if(searchString.length > 0 && input.attr('data-last-search') != searchString){ // Check to make sure queries aren't repeatedly running
        results = fishpond.search(searchString);
        var list = $("#search ul");
        list.show();
        list.empty();

        // Build list of result options
        for(var resultIndex in results){
          var result = results[resultIndex];
          var item = $("<li></li>");
          var link = $('<a href="#">' + result.fish.title + '</a>');
          link.attr('data-fish-id', result.fish.id);

          // Result click handler - sets sliders to fishes values
          link.click(function(){
            input.val("");
            $(".filter").removeAttr('checked'); // Uncheck all filters

            // Find the fish in the pond
            var fish = fishpond.pond.find_fish($(this).attr('data-fish-id'));

            // Set sliders to correct values
            for(var tagIndex in fish.humanized_tags){
              var tag = fish.humanized_tags[tagIndex];
              console.log(tag.slug + " = " + tag.value);
              var slider = $(".slider[data-slug='" + tag.slug + "']").slider('value', parseInt(tag.value, 10));
              slider.prev("input").attr("checked", "checked");
            }

          });
          item.append(link);
          list.append(item);

        }
      } else if(searchString.length == 0){ // Hide links if no search string
        var list = $("#search ul");
        list.hide();
      }
      input.attr('data-last-search', searchString);
    }


			// Update Favourites List
			// Checks favourites in localStorage and updates display accordingly
			function updateFavourites(){
				var ui = $("#favourites");
				var ul = ui.find("ul");
				ul.empty();

				var favourites = getFavourites();
				if(favourites.length == 0){
					ul.append("<li>Nothing saved</li>");
				} else {
					for(var i = 0; i < favourites.length; i++){
						var fish_id = favourites[i];
						var li = $("<li />");
						var a = $("<a />");
						var fish = fishpond.pond.find_fish(fish_id);

						a.html(fish.title);
						a.attr('href', '#');
						a.attr('data-fish-id', fish_id);

						a.click(function(e){
							e.preventDefault();
							showFishMetadata($(this).attr('data-fish-id'));
						});
						li.append(a);
						ul.append(li);
					}
				}
			}

			// Adds a fish ID to favourites
			function addToFavourites(fish_id){
				console.log("Adding to favourites: " + fish_id);

				var favourites = getFavourites();
				if(favourites.indexOf(fish_id) == -1){
					favourites.push(fish_id);
				}
				storeFavourites(favourites);
				updateFavourites();
			}

			// Removes a fish ID from favourites
			function removeFromFavourites(fish_id){
				console.log("Removing from favourites: " + fish_id);
				var favourites = getFavourites();
				if(favourites.indexOf(fish_id) != -1){
					favourites.splice(favourites.indexOf(fish_id), 1);
				}
				storeFavourites(favourites);
				updateFavourites();
			}

			// Returns true if fish ID is on favourites
			function isFavourite(fish_id){
				var favourites = getFavourites();
				return favourites.indexOf(fish_id) != -1;
			}

			// Returns favourite fish in an Array
			function getFavourites(){
				var str = localStorage["favourites"];
				if(str){
					return str.split(",");
				}
				return [];
			}

			function storeFavourites(arr){
				localStorage.setItem("favourites", arr.join(","));
			}
  });


	// console.log(results);



