CONTRIBUTING
============

This document describes the steps to contribute to the ifish "just works" starter kit Javascript code.

Installation
------------

http://coffeescript.org/#installation

Running
-------

coffee -wc ./javascripts/ifish.coffee